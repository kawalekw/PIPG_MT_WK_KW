﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour {

	public gracz player;
	public GameObject enemyContainer;

	public Text healthText;
	public Text ammoText;
	public Text enemyText;
	public Text infoText;

	private bool gameOver = false;
	private float resetTimer = 3f;

	void Start () {
		infoText.text = "";
	}

	

	void Update () {
		healthText.text = "Health: " + player.Health;
		ammoText.text = "Ammo: " + player.Ammo;
		int aliveEnemies = 0;
		foreach (Enemy enemy in enemyContainer.GetComponentsInChildren<Enemy> ()) {
			if (enemy.Killed == false){
				aliveEnemies++;
			}
		}
		enemyText.text = "Enemies: " + aliveEnemies;
		if (aliveEnemies == 0){
			gameOver = true;
			infoText.text = "You Won!";
		}
		if (player.Killed == true){
			gameOver = true;
			infoText.text = "You Lose :<";
		}
		if (gameOver == true) {
			resetTimer -= Time.deltaTime;
			if (resetTimer <= 0) {
				SceneManager.LoadScene ("menu");
			}
		}
	}
}
