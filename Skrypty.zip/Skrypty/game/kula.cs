﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class kula : MonoBehaviour {

	public float speed =8f;
	public float life = 2f;
	public int damage = 5;

	private float lifeTimer;

	private bool shotByPlayer;
	public bool ShotByPlayer { get {return shotByPlayer;} set {shotByPlayer = value;} }

	// Use this for initialization
	void OnEnable () {
		lifeTimer = life;
		
	}
	
	// Update is called once per frame
	void Update () {
		transform.position +=transform.forward * speed * Time.deltaTime;
		lifeTimer -= Time.deltaTime;
		if (lifeTimer <= 0f) {
			gameObject.SetActive (false);
		}
		
	}
}
