﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class ShootingEnemy : Enemy {

	public AudioSource deathSound;
	public float shootingInterval = 4f;
	public float shootingDistance = 3f;
	private gracz player;	
	private float shootingTimer;

	private NavMeshAgent agent;

	// Use this for initialization
	void Start () {
		player = GameObject.Find ("gracz").GetComponent<gracz>();
		agent = GetComponent<NavMeshAgent> ();
		shootingTimer = Random.Range(0, shootingInterval);

		agent.SetDestination(player.transform.position);
	}
	
	// Update is called once per frame
	void Update () {
		if (player.Killed == true) {
			agent.enabled = false;
			this.enabled = false;
		}
		shootingTimer -= Time.deltaTime;
		if (shootingTimer <= 0 && Vector3.Distance(transform.position, player.transform.position) <= shootingDistance) {
			shootingTimer = shootingInterval;			
			GameObject kula = ObjectPoolingManager.Instance.GetBullet (false);
			kula.transform.position = transform.position;
			kula.transform.forward = (player.transform.position - transform.position).normalized;
			agent.SetDestination(player.transform.position);
		}
		
	}
	protected override void OnKill ()
	{
		base.OnKill ();
		deathSound.Play ();
		agent.enabled = false;
		this.enabled = false;
		transform.localEulerAngles = new Vector3 (10, transform.localEulerAngles.y, transform.localEulerAngles.z);
	}
}
